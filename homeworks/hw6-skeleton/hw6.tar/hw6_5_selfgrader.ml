open CommonGrade
open Hw6_5

(* NOTE that this grader is not complete; any expression equivalent to the constant 0 is OK.  Read the specification. *)
let _ = output (fun () ->
  (diff (CONST 1) "x") = CONST 0)

